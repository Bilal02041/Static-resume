interface Job {
    title: string;
    company: string;
    years: string;
}

interface Education {
    degree: string;
    institution: string;
    years: string;
}

interface ResumeData {
    name: string;
    email: string;
    phone: string;
    location: string;
    job: Job;
    education: Education;
    skills: string[];
}

function generateResume(data: ResumeData) {
    const resumeDiv = document.getElementById('resume');

    if (resumeDiv) {
        resumeDiv.innerHTML = `
            <h1>${data.name}</h1>
            <p>${data.email} | ${data.phone} | ${data.location}</p>
            
            <h2>Experience</h2>
            <h3>${data.job.title} - ${data.job.company}</h3>
            <p>${data.job.years}</p>
            
            <h2>Education</h2>
            <h3>${data.education.degree} - ${data.education.institution}</h3>
            <p>${data.education.years}</p>
            
            <h2>Skills</h2>
            <ul>
                ${data.skills.map(skill => `<li>${skill}</li>`).join('')}
            </ul>
        `;
    }
}

document.getElementById('resumeForm')?.addEventListener('submit', function(event) {
    event.preventDefault();

    const name = (document.getElementById('name') as HTMLInputElement).value;
    const email = (document.getElementById('email') as HTMLInputElement).value;
    const phone = (document.getElementById('phone') as HTMLInputElement).value;
    const location = (document.getElementById('location') as HTMLInputElement).value;

    const jobTitle = (document.getElementById('job1') as HTMLInputElement).value;
    const company = (document.getElementById('company1') as HTMLInputElement).value;
    const yearsJob = (document.getElementById('years1') as HTMLInputElement).value;

    const degree = (document.getElementById('degree') as HTMLInputElement).value;
    const institution = (document.getElementById('institution') as HTMLInputElement).value;
    const yearsEdu = (document.getElementById('yearsEdu') as HTMLInputElement).value;

    const skills = (document.getElementById('skills') as HTMLInputElement).value.split(',');

    const resumeData: ResumeData = {
        name,
        email,
        phone,
        location,
        job: {
            title: jobTitle,
            company,
            years: yearsJob
        },
        education: {
            degree,
            institution,
            years: yearsEdu
        },
        skills
    };

    generateResume(resumeData);

    // Display the resume container after generating
    const resumeContainer = document.querySelector('.resume-container') as HTMLElement;
    resumeContainer.style.display = 'block';
});
