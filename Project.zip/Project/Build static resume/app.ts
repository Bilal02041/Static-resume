interface Job {
    title: string;
    company: string;
    years: string;
    description: string;
}

interface Education {
    institution: string;
    degree: string;
    years: string;
}

const experience: Job[] = [
    {
        title: "Software Engineer",
        company: "Tech Solutions",
        years: "2021 - Present",
        description: "Developed and maintained web applications using modern web technologies."
    },
    {
        title: "Junior Developer",
        company: "Web Innovators",
        years: "2019 - 2021",
        description: "Assisted in building client websites and improving user interface design."
    }
];

const education: Education[] = [
    {
        institution: "University of Technology",
        degree: "BSc in Computer Science",
        years: "2015 - 2019"
    },
    {
        institution: "Tech High School",
        degree: "High School Diploma",
        years: "2011 - 2015"
    }
];

const skills: string[] = ["JavaScript", "TypeScript", "React", "CSS", "HTML", "Git"];

function populateExperience() {
    const experienceList = document.getElementById('experience-list');
    experience.forEach((job) => {
        const jobDiv = document.createElement('div');
        jobDiv.innerHTML = `
            <h3>${job.title} - ${job.company}</h3>
            <p>${job.years}</p>
            <p>${job.description}</p>
        `;
        experienceList?.appendChild(jobDiv);
    });
}

function populateEducation() {
    const educationList = document.getElementById('education-list');
    education.forEach((edu) => {
        const eduDiv = document.createElement('div');
        eduDiv.innerHTML = `
            <h3>${edu.degree}</h3>
            <p>${edu.institution}</p>
            <p>${edu.years}</p>
        `;
        educationList?.appendChild(eduDiv);
    });
}

function populateSkills() {
    const skillsList = document.getElementById('skills-list');
    skills.forEach((skill) => {
        const skillItem = document.createElement('li');
        skillItem.textContent = skill;
        skillsList?.appendChild(skillItem);
    });
}

document.addEventListener('DOMContentLoaded', () => {
    populateExperience();
    populateEducation();
    populateSkills();
});
